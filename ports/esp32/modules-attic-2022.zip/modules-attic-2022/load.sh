sudo chmod a+rw /dev/ttyUSB0 && cd ../../../ && make -C ports/esp32 LV_CFLAGS="-DLV_COLOR_DEPTH=16" BOARD=GENERIC deploy && cd ports/esp32/modules/

